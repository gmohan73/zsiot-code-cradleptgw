#!/bin/bash
cppython installer.py start
