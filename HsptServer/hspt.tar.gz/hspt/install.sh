#!/bin/bash
echo "INSTALLATION httpserver handler on:" >> install.log
date >> install.log
