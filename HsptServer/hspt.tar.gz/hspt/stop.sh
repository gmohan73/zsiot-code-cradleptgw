#!/bin/bash
cppython installer.py stop
