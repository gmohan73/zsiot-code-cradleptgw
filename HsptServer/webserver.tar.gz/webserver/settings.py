# Common settings used by simple_custom_dashboard

# Used for logging or anytime the app name is needed
APP_NAME = 'webserver'
