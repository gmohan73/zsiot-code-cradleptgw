#!/bin/bash
cppython hotspotserver.py